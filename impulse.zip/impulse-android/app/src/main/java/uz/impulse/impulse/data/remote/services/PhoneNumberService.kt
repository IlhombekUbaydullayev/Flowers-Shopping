package uz.impulse.impulse.data.remote.services

interface PhoneNumberService {


}