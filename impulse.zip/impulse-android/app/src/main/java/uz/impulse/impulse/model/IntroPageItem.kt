package uz.impulse.impulse.model

data class IntroPageItem(
    var img: String,
    var title: String,
    var description: String
)