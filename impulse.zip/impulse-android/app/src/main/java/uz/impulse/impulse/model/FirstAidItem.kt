package uz.impulse.impulse.model

class FirstAidItem {
    var icon: Int? = null
    var name: String? = null

    constructor(icon: Int?, name: String?) {
        this.icon = icon
        this.name = name
    }

    constructor()
}