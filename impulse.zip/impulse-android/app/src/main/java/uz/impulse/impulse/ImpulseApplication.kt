package uz.impulse.impulse

import android.app.Application

class ImpulseApplication: Application() {
    override fun onCreate() {
        super.onCreate()
    }
}