package uz.impulse.impulse.model

data class HomeItem(
    val tvText: String,
    val ivRightIcon: Int
)
